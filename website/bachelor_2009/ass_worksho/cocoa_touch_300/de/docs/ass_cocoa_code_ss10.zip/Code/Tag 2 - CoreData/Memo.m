// 
//  Memo.m
//  Tag 2 - CoreData
//
//  Created by Leicester on 08.03.10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "Memo.h"


@implementation Memo 

@dynamic date;
@dynamic text;

-(NSString*)description{
	NSDateFormatter* dateFormatter = [[[NSDateFormatter alloc] init] autorelease];
	[dateFormatter setDateStyle:NSDateFormatterShortStyle];
	[dateFormatter setTimeStyle:NSDateFormatterShortStyle];
	return [NSString stringWithFormat:@"%@ - %@", [dateFormatter stringFromDate:self.date], self.text];
}
@end
