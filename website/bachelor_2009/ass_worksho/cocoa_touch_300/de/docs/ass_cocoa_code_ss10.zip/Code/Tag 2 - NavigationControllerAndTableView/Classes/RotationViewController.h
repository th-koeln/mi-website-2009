#import <UIKit/UIKit.h>

@interface RotationViewController : UIViewController {
	IBOutlet UIView* colourView;
	IBOutlet UISlider* redSlider;
	IBOutlet UISlider* greenSlider;
	IBOutlet UISlider* blueSlider;
}

- (IBAction) valueChanged:(id)sender;

@end

