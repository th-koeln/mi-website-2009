#import <UIKit/UIKit.h>

@class HelloCocoa2ViewController;

@interface HelloCocoa2AppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    HelloCocoa2ViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet HelloCocoa2ViewController *viewController;

@end

