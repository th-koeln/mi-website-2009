#import "HelloCocoa2ViewController.h"

@implementation HelloCocoa2ViewController

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	[self.view setBackgroundColor:[UIColor blackColor]];
	
	UILabel* label = [[UILabel alloc] init];
	[label setFrame:CGRectMake(10, 10, 300, 30)];
	[label setText:@"Gedanken bitte hier eintragen:"];
	[label setBackgroundColor:[UIColor clearColor]];
	[label setTextColor:[UIColor whiteColor]];
	[self.view addSubview:label];
	[label release];
	
	textField = [[UITextField alloc] init];
	[textField setFrame:CGRectMake(10, 50, 300, 30)];
	[textField setBackgroundColor:[UIColor clearColor]];
	[textField setBorderStyle:UITextBorderStyleRoundedRect];
	[textField setPlaceholder:@"black is beautiful"];
	[textField setDelegate:self];
	[self.view addSubview:textField];
	
	UIButton* saveButton = [UIButton buttonWithType:UIButtonTypeCustom];
	[saveButton setFrame:CGRectMake(10, 90, 80, 40)];
	[saveButton setShowsTouchWhenHighlighted:YES];
	[saveButton setBackgroundColor:[UIColor clearColor]];
	[saveButton setTitle:@"save" forState:UIControlStateNormal];
	[saveButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	[saveButton addTarget:self action:@selector(save:) forControlEvents:UIControlEventTouchUpInside];
	[self.view addSubview:saveButton];
	
	UIButton* clearButton = [UIButton buttonWithType:UIButtonTypeCustom];
	[clearButton setFrame:CGRectMake(210, 90, 80, 40)];
	[clearButton setShowsTouchWhenHighlighted:YES];
	[clearButton setBackgroundColor:[UIColor clearColor]];
	[clearButton setTitle:@"clear" forState:UIControlStateNormal];
	[clearButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
	[clearButton addTarget:self action:@selector(clear:) forControlEvents:UIControlEventTouchUpInside];
	[self.view addSubview:clearButton];
}

- (void)save:(id)sender{
	NSLog(@"%@", textField.text);
}

- (void)clear:(id)sender{
	textField.text = nil;
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
}


- (void)dealloc {
	
    [super dealloc];
}

@end
