#import "FontViewerViewController.h"

@implementation FontViewerViewController

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
	return [[UIFont familyNames] count];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
	return 1;	
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
	
	UITableViewCell* cell = [table dequeueReusableCellWithIdentifier:@"chatzelle"];
	
	if(cell == nil){
		cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"chatzelle"];
	}
	
	cell.textLabel.text = [[UIFont familyNames] objectAtIndex:indexPath.row];
	[cell.textLabel setFont:[UIFont fontWithName:[[UIFont familyNames] objectAtIndex:indexPath.row] size:16.0f]];
	
	
	return cell;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

- (void)viewDidUnload {
	[table release];
	table = nil;
}


- (void)dealloc {
	[table release];
	
    [super dealloc];
}

@end
