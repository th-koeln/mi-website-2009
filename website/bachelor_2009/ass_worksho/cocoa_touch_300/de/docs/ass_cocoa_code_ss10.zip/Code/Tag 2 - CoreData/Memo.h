//
//  Memo.h
//  Tag 2 - CoreData
//
//  Created by Leicester on 08.03.10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <CoreData/CoreData.h>


@interface Memo :  NSManagedObject  
{
}

@property (nonatomic, retain) NSDate * date;
@property (nonatomic, retain) NSString * text;

@end



