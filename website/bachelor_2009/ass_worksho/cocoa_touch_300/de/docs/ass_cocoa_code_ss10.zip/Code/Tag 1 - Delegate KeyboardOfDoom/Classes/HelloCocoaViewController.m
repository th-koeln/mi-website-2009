#import "HelloCocoaViewController.h"

@implementation HelloCocoaViewController

-(void)viewDidLoad{
	textField.delegate = self;
}

- (IBAction)clearTextfield:(id)sender{
	textField.text = nil;
	// oder textField.text = @"";
}

- (IBAction)copyContent:(id)sender{
	NSLog(@"%@", textField.text);
}

- (void)dealloc {
	[textField release];
    [super dealloc];
}

#pragma mark -
#pragma mark UITextFieldDelegate
-(BOOL)textFieldShouldReturn:(UITextField *)value{
	[textField resignFirstResponder];
	return YES;
}

@end
