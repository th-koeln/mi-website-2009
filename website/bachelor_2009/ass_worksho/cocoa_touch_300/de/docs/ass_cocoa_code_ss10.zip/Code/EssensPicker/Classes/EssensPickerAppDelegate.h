//
//  EssensPickerAppDelegate.h
//  EssensPicker
//
//  Created by icke on 07.03.10.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@class EssensPickerViewController;

@interface EssensPickerAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    EssensPickerViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet EssensPickerViewController *viewController;

@end

