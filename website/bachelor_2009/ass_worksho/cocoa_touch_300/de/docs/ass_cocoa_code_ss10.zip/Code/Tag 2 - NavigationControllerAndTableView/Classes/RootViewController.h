//
//  RootViewController.h
//  Tag 2 - NavigationControllerAndTableView
//
//  Created by Leicester on 10.03.10.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

@interface RootViewController : UITableViewController {
	NSArray* data;
}

@end
