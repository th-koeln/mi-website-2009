#import "EssensPickerViewController.h"

@interface EssensPickerViewController()

-(void)setComponent:(uint)value;

@end


@implementation EssensPickerViewController

- (void) viewWillAppear:(BOOL)animated{
	// ----------------------------------------------
	picker.delegate = self;
	picker.dataSource = self;
	// --- notwendig um den Picker sichtbar zu machen
	
	// setzt Montag
	//[picker selectRow:3 inComponent:0 animated:YES];
	int temp = [[NSUserDefaults standardUserDefaults] integerForKey:@"essenessen"];
	[self setComponent:temp];
	
}


#pragma mark UIPickerViewDelegate

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
	if(row == 0){
		return @"Montag";
	}
	else if(row == 1){
		return @"Dienstag";
	}
	else if(row == 2){
		return @"Mittwoch";
	}
	else if(row == 3){
		return @"Donnerstag";
	}
	else if(row == 4){
		return @"Freitag";
	}
	else return @"Wochenende";
}

-(void)setComponent:(uint)value{
	[picker selectRow:value inComponent:0 animated:YES];
	label.text = @"";
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component{
	[[NSUserDefaults standardUserDefaults] setInteger:row forKey:@"essenessen"];
	if(row == 0){
		label.text = @"Pichelsteiner Eintopf mit Wursteinlage";
	}
	else if(row == 1){
		label.text = @"Spätzlepfanne mit Hackfleisch";
	}
	else if(row == 2){
		label.text = @"Farfalle Nudeln in Käse-Sahnesauce";
	}
	else if(row == 3){
		label.text = @"Kartoffel-Lauch-Gratin";
	}
	else if(row == 4){
		label.text = @"Serbisches Reisfleisch mit Paprika";
	}
}

#pragma mark UIPickerViewDataSource

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
	return 1;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
	return 5;
}

- (void) dealloc{
	[label release];
	[picker release];
	[super dealloc];
}


@end

