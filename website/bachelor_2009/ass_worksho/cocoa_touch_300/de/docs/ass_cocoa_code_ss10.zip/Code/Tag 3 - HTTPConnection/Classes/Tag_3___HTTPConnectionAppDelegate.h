//
//  Tag_3___HTTPConnectionAppDelegate.h
//  Tag 3 - HTTPConnection
//
//  Created by Leicester on 11.03.10.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

@interface Tag_3___HTTPConnectionAppDelegate : NSObject <UIApplicationDelegate> {
    
    UIWindow *window;
    UINavigationController *navigationController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet UINavigationController *navigationController;

@end

