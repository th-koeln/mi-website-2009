#import <UIKit/UIKit.h>

@interface FontViewerViewController : UIViewController <UITableViewDelegate, UITableViewDataSource> {
	IBOutlet UITableView* table;
}

@end

