//
//  Aufgabe8_AnimationsViewController.m
//  Aufgabe8-Animations
//
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import "Aufgabe8_AnimationsViewController.h"

@implementation Aufgabe8_AnimationsViewController


- (void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {	
	UITouch *touch = [[event allTouches] anyObject];
	
	[UIView beginAnimations:@"MoveMonster" context:nil];
	[UIView setAnimationDelegate:self];
	monsterImageView.center = [touch locationInView:self.view];
	[UIView commitAnimations];
}


- (void)animationDidStop:(NSString *)animationID finished:(NSNumber *)finished context:(void *)context{
	NSLog(@"DidStop: %@", animationID);
	if([animationID isEqualToString:@"MoveMonster"]){
		[UIView beginAnimations:@"WobbleMonster" context:nil];
		[UIView setAnimationDelegate:self];
		[UIView setAnimationRepeatCount:2];
		[UIView setAnimationDuration:0.2];
		monsterImageView.alpha = 0.0;
		[UIView commitAnimations];
		
	}else if([animationID isEqualToString:@"WobbleMonster"]){
		[UIView beginAnimations:@"UnhideMonster" context:nil];
		[UIView setAnimationDuration:0.2];
		monsterImageView.alpha = 1.0;
		[UIView commitAnimations];	
	}
}



- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)dealloc {
    [super dealloc];
}

@end
