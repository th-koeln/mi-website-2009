//
//  Parser.m
//  TwitterLesen
//
//  Created by icke on 10.03.10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "Parser.h"

@interface Parser ()
@property (nonatomic, retain, readwrite) NSMutableArray* texte;
@property (nonatomic, retain, readwrite) NSMutableData* data;
@end


@implementation Parser

- (id) initWithData:(NSData*)data_{
	self = [super init];
	if (self != nil) {
		self.data = [NSMutableData dataWithData:data_];
		self.texte = [[NSMutableArray alloc] init];
		content = nil;
	}
	return self;
}

- (void)start{
	parser = [[NSXMLParser alloc] initWithData:self.data];
	parser.delegate = self;
	statusIsOpen = NO;
	[parser parse];
}

@synthesize delegate;
@synthesize texte;
@synthesize data;

- (void) dealloc{
	self.texte = nil;
	self.data = nil;
	
	[parser abortParsing];
	[parser release];
	
	[super dealloc];
}

#pragma mark -
#pragma mark NSXMLParserDelegate methods

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qualifiedName attributes:(NSDictionary *)attributeDict{

	if(!statusIsOpen && [elementName isEqualToString:@"status"]){
		statusIsOpen = YES;
	}
	if(statusIsOpen && [elementName isEqualToString:@"text"]){
		statusIsOpen = NO;
		textIsOpen = YES;
	}
	//NSLog(@"%@", elementName);
}

- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string{
	if(textIsOpen){
		if(content == nil){
			content = [[NSMutableString alloc] initWithString:string];
		}
		else{
			[content appendString:string];
		}
	}
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName{
	if(textIsOpen && [elementName isEqualToString:@"text"]){
		textIsOpen = NO;
		[self.texte addObject:content];
		[content release];
		content = nil;
	}
}

- (void)parserDidEndDocument:(NSXMLParser *)parser{
	NSLog(@"%@", self.texte);
	[delegate parsingFinished:self withInfos:self.texte];
}

@end
