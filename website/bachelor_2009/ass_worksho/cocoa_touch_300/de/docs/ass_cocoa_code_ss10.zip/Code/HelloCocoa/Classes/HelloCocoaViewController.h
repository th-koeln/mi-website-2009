#import <UIKit/UIKit.h>

@interface HelloCocoaViewController : UIViewController {
	IBOutlet UITextField* textField;
}

- (IBAction)clearTextfield:(id)sender;
- (IBAction)copyContent:(id)sender;

@end

