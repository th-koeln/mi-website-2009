#import <UIKit/UIKit.h>

@class FontViewerViewController;

@interface FontViewerAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    FontViewerViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet FontViewerViewController *viewController;

@end

