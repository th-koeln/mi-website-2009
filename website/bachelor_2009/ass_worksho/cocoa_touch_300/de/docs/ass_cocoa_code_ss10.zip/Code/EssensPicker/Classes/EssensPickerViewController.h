#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

@interface EssensPickerViewController : UIViewController <UIPickerViewDelegate, UIPickerViewDataSource> {
    IBOutlet UILabel *label;
    IBOutlet UIPickerView *picker;
}

@end