#import "HelloCocoaAppDelegate.h"
#import "HelloCocoaViewController.h"

@implementation HelloCocoaAppDelegate

@synthesize window;
@synthesize viewController;


- (void)applicationDidFinishLaunching:(UIApplication *)application {    
    
	[application setStatusBarStyle:UIStatusBarStyleBlackOpaque];
    // Override point for customization after app launch    
    [window addSubview:viewController.view];
    [window makeKeyAndVisible];
}


- (void)dealloc {
    [viewController release];
    [window release];
    [super dealloc];
}


@end
