//
//  RootViewController.h
//  Tag 2 - CoreData
//
//  Created by Leicester on 08.03.10.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

@interface RootViewController : UITableViewController <NSFetchedResultsControllerDelegate> {
	NSFetchedResultsController *fetchedResultsController;
	NSManagedObjectContext *managedObjectContext;
	
	IBOutlet UIView* headerView;
	IBOutlet UITextField* textField;
}

@property (nonatomic, retain) NSFetchedResultsController *fetchedResultsController;
@property (nonatomic, retain) NSManagedObjectContext *managedObjectContext;

- (IBAction)insertNewObject;
- (IBAction)searchButtonPressed:(id)button;

@end
