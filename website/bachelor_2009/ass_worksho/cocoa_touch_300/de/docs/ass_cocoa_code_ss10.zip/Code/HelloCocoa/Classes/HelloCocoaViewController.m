#import "HelloCocoaViewController.h"

@implementation HelloCocoaViewController

- (IBAction)clearTextfield:(id)sender{
	textField.text = nil;
	// oder textField.text = @"";
}

- (IBAction)copyContent:(id)sender{
	NSLog(@"%@", textField.text);
}



- (void)dealloc {
	[textField release];
    [super dealloc];
}

@end
