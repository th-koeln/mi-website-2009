//
//  Parser.h
//  TwitterLesen
//
//  Created by icke on 10.03.10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@class Parser;
@protocol ParserDelegate
// weak reference
- (void) parsingFinished:(Parser*)parser withInfos:(NSMutableArray* )infos;
@end

@interface Parser : NSObject {
	NSXMLParser* parser;
	NSMutableArray* texte;
	NSMutableData* data;
	id delegate;
	
	BOOL statusIsOpen;
	BOOL textIsOpen;
	NSMutableString* content;
}

@property (nonatomic, assign) id delegate;
@property (nonatomic, retain, readonly) NSMutableArray* texte;
@property (nonatomic, retain, readonly) NSMutableData* data;

- (void)start;

@end
