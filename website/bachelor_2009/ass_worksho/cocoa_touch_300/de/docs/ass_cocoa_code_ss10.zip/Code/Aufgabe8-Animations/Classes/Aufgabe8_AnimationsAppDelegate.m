//
//  Aufgabe8_AnimationsAppDelegate.m
//  Aufgabe8-Animations
//
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import "Aufgabe8_AnimationsAppDelegate.h"
#import "Aufgabe8_AnimationsViewController.h"

@implementation Aufgabe8_AnimationsAppDelegate

@synthesize window;
@synthesize viewController;


- (void)applicationDidFinishLaunching:(UIApplication *)application {    
    
    // Override point for customization after app launch    
    [window addSubview:viewController.view];
    [window makeKeyAndVisible];
}


- (void)dealloc {
    [viewController release];
    [window release];
    [super dealloc];
}


@end
