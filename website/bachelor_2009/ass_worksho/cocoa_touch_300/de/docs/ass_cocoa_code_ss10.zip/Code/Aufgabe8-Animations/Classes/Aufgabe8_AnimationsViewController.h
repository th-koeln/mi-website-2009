//
//  Aufgabe8_AnimationsViewController.h
//  Aufgabe8-Animations
//
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Aufgabe8_AnimationsViewController : UIViewController {
	IBOutlet UIImageView* monsterImageView;
}

@end

