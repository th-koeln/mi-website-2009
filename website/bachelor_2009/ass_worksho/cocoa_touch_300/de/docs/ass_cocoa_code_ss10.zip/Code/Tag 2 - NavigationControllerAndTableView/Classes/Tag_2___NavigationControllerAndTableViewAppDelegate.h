//
//  Tag_2___NavigationControllerAndTableViewAppDelegate.h
//  Tag 2 - NavigationControllerAndTableView
//
//  Created by Leicester on 10.03.10.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

@interface Tag_2___NavigationControllerAndTableViewAppDelegate : NSObject <UIApplicationDelegate> {
    
    UIWindow *window;
    UINavigationController *navigationController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet UINavigationController *navigationController;

@end

