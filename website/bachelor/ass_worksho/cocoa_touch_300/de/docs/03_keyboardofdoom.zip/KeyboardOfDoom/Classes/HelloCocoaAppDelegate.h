#import <UIKit/UIKit.h>

@class HelloCocoaViewController;

@interface HelloCocoaAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    HelloCocoaViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet HelloCocoaViewController *viewController;

@end

