//
//  viewcontrollerdemoViewController.m
//  viewcontrollerdemo
//
//  Created by Thomas Heß on 7/26/10.
//  Copyright FH Köln Campus Gummersbach 2010. All rights reserved.
//

#import "viewcontrollerdemoViewController.h"

@implementation viewcontrollerdemoViewController

@synthesize imagePicker;

/*
// The designated initializer. Override to perform setup that is required before the view is loaded.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/


/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
}
*/


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
	self.imagePicker = nil;
	[imageView release];
    [super dealloc];
}


- (void)selectImageFromLibrary {
	imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
	[self presentModalViewController:imagePicker animated:YES];
}

- (void)selectImageFromCamera {
	#if TARGET_IPHONE_SIMULATOR
	imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
	#warning *** Simulator does not support camera input: using photolibrary instead
	#else
	imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
	#endif
	[self presentModalViewController:imagePicker animated:YES];
	
}

#pragma mark -
#pragma mark UIImagePickerControllerDelegate

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
	UIImage *selectedImage = [info valueForKey:@"UIImagePickerControllerOriginalImage"];
		
	if (imageView != nil) {
		[imageView removeFromSuperview];
		[imageView release];
	}
	
	imageView = [[UIImageView alloc] initWithImage:selectedImage];
	[self.view addSubview:imageView];
	
	[picker dismissModalViewControllerAnimated:YES];
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
	[picker dismissModalViewControllerAnimated:YES];
}

@end
