//
//  viewcontrollerdemoViewController.h
//  viewcontrollerdemo
//
//  Created by Thomas Heß on 7/26/10.
//  Copyright FH Köln Campus Gummersbach 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface viewcontrollerdemoViewController : UIViewController <UIImagePickerControllerDelegate> {
	UIImageView *imageView;
}

@property (nonatomic, retain) IBOutlet UIImagePickerController *imagePicker;

- (IBAction)selectImageFromLibrary;
- (IBAction)selectImageFromCamera;

@end

