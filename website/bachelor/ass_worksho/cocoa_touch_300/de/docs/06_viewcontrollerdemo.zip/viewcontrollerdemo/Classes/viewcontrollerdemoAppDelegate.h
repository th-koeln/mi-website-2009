//
//  viewcontrollerdemoAppDelegate.h
//  viewcontrollerdemo
//
//  Created by Thomas Heß on 7/26/10.
//  Copyright FH Köln Campus Gummersbach 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@class viewcontrollerdemoViewController;

@interface viewcontrollerdemoAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    viewcontrollerdemoViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet viewcontrollerdemoViewController *viewController;

@end

