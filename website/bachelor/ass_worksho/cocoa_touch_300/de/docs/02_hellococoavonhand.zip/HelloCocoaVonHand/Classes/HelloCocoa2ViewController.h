#import <UIKit/UIKit.h>

@interface HelloCocoa2ViewController : UIViewController <UITextFieldDelegate> {
	UITextField* textField;
}

@end

