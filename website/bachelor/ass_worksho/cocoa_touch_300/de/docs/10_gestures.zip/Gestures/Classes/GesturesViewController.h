//
//  GesturesViewController.h
//  Gestures
//
//  Created by Daniel Bertram on 03.07.10.
//  Copyright RockAByte 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GesturesViewController : UIViewController <UIGestureRecognizerDelegate, UIScrollViewDelegate> {
	IBOutlet UIScrollView* viewToZoom;
	UIImageView* imageView;
}

@end

