#import "GesturesViewController.h"

const float minZoomLevel = 0.25f;
const float maxZoomLevel = 3.0f;

@implementation GesturesViewController


- (void)viewDidLoad {
    [super viewDidLoad];
	
	imageView = [[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"domo4.jpg"]] autorelease];
	[viewToZoom addSubview:imageView];
	viewToZoom.contentOffset = imageView.center;
	viewToZoom.delegate = self;
	viewToZoom.contentSize = imageView.frame.size;
	
	UIPinchGestureRecognizer* pincher = [[[UIPinchGestureRecognizer alloc] initWithTarget:self action:@selector(zoomGreenView:)] autorelease];
	[viewToZoom addGestureRecognizer:pincher];
	
}

- (void)zoomGreenView:(UIPinchGestureRecognizer*)gesture{
	float temp = 0.0f;
	if (gesture.scale > 1.0f) {
		temp = 1.05f;
	}else {
		temp = 0.95f;
	}
	temp = viewToZoom.zoomScale * temp;
	if (temp < minZoomLevel) {
		temp = minZoomLevel;
	}else if (temp > maxZoomLevel) {
		temp = maxZoomLevel;
	} 
	
	viewToZoom.minimumZoomScale = temp;
	viewToZoom.maximumZoomScale = temp;
	viewToZoom.zoomScale = temp;
}

- (UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView{
	return imageView;
}

- (void)viewDidUnload {

}


- (void)dealloc {
    [super dealloc];
}

@end
