//
//  RootViewController.h
//  workshopcollection
//
//  Created by Thomas Heß on 7/27/10.
//  Copyright FH Köln Campus Gummersbach 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RootViewController : UITableViewController {
}

@end
