//
//  SomeViewController.h
//  navigationdemo
//
//  Created by Thomas Heß on 7/25/10.
//  Copyright 2010 FH Köln Campus Gummersbach. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface SomeViewController : UIViewController {

}

@property (nonatomic) int someNumber;

@end
