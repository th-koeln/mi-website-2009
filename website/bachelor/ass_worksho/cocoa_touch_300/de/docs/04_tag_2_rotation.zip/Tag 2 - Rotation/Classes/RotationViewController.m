#import "RotationViewController.h"

@implementation RotationViewController

- (IBAction) valueChanged:(id)sender{
	[colourView setBackgroundColor:[UIColor colorWithRed:redSlider.value green:greenSlider.value blue:blueSlider.value alpha:1.0]];
}

// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    return YES;
}

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	[colourView release];
	[redSlider release];
	[greenSlider release];
	[blueSlider release];
	colourView = nil;
	redSlider = nil;
	greenSlider = nil;
	blueSlider = nil;
}


- (void)dealloc {
	[colourView release];
	[redSlider release];
	[greenSlider release];
	[blueSlider release];
	
    [super dealloc];
}

@end
