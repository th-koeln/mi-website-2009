#import <UIKit/UIKit.h>

@class RotationViewController;

@interface RotationAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    RotationViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet RotationViewController *viewController;

@end

