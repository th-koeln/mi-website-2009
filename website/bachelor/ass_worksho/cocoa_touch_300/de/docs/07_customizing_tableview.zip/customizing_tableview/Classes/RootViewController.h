//
//  RootViewController.h
//  tableviewdemo
//
//  Created by Thomas Heß on 7/15/10.
//  Copyright FH Köln Campus Gummersbach 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RootViewController : UITableViewController {
}

@end
