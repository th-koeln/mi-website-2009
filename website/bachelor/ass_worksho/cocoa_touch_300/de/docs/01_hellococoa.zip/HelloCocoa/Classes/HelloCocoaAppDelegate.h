//
//  HelloCocoaAppDelegate.h
//  HelloCocoa
//
//  Created by Daniel Bertram on 07.07.10.
//  Copyright RockAByte 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@class HelloCocoaViewController;

@interface HelloCocoaAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    HelloCocoaViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet HelloCocoaViewController *viewController;

@end

