//
//  HelloCocoaViewController.h
//  HelloCocoa
//
//  Created by Daniel Bertram on 07.07.10.
//  Copyright RockAByte 2010. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HelloCocoaViewController : UIViewController {
	IBOutlet UITextField* textField;
}

- (IBAction)deleteText;
- (IBAction)copyText;

@end

