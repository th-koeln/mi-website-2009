//
//  HelloCocoaViewController.m
//  HelloCocoa
//
//  Created by Daniel Bertram on 07.07.10.
//  Copyright RockAByte 2010. All rights reserved.
//

#import "HelloCocoaViewController.h"

@implementation HelloCocoaViewController

- (void)viewDidUnload {
	[textField release];
	textField = nil;
}


- (void)dealloc {
	[textField release];
	
    [super dealloc];
}

#pragma mark -
#pragma mark actions

- (IBAction)deleteText{
	textField.text = nil;
}

- (IBAction)copyText{
	NSLog(@"%@", textField.text);
}

@end
