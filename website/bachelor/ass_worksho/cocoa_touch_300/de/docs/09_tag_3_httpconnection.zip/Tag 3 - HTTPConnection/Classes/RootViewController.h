//
//  RootViewController.h
//  Tag 3 - HTTPConnection
//
//  Created by Leicester on 11.03.10.
//  Copyright __MyCompanyName__ 2010. All rights reserved.
//

#import "Parser.h"

@interface RootViewController : UITableViewController <UISearchBarDelegate, ParserDelegate> {
	
	IBOutlet UISearchBar* searchBar;
	
	NSURLConnection* connection;
	NSURLRequest* request;
	NSMutableData* data;
	Parser* parser;
	
	NSArray* content;
}

@end
